Preside-Objects directory
=========================

This folder is used for defining PresideCMS data objects.