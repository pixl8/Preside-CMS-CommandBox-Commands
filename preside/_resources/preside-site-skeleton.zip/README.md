Preside-CMS-Skeleton
====================

A skeleton PresideCMS application to be used as a starting point for all applications.
